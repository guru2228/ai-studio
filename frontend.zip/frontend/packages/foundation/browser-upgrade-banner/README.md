# @coze-foundation/browser-upgrade-banner

低版本浏览器升级条幅

## Features

- [x] eslint & ts
- [x] esm bundle
- [x] umd bundle
- [x] storybook

## Commands

- init: `rush update`
- dev: `npm run dev`
- build: `npm run build`
