# @coze-devops/json-link-preview

> Project template for react component with storybook and supports publish independently.

## Features

- [x] eslint & ts
- [x] esm bundle
- [x] umd bundle
- [x] storybook

## Commands

- init: `rush update`
- dev: `npm run dev`
- build: `npm run build`
