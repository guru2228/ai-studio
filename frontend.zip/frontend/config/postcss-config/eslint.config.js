const { defineConfig } = require('@coze-arch/eslint-config');

module.exports = defineConfig({
  preset: 'node',
  packageRoot: __dirname,
});
