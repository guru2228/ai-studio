require('sucrase/register/ts');

const { defineConfig } = require('./define-config');

module.exports = { defineConfig };
