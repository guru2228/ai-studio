require('sucrase/register');

require('./scripts/serve.ts');
