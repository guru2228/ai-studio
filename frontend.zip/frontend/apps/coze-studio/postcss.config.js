module.exports = require('@coze-arch/postcss-config');
