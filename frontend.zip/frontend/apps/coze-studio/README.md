# [🦀️ Rsbuild](https://rsbuild.dev/zh/guide/start/index) & React App
Web项目初始化模板，已包含功能：
* react + react-router
* slardar
* less(module), [tailwindcss](https://tailwindcss.com/docs)
* vitest
